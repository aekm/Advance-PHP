<?php

define('URL','http://localhost/your-project-name/');



