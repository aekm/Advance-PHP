<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="<?= URL ?>public/css/your-css-file.css">
<script src="<?= URL ?>public/js/your-js-file.js"></script>





<!-- you can insert your html code here without any <html> or <body> tag before that -->
