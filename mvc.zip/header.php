<!DOCTYPE html>
<html lang="en">
<head>

    <base href="<?= URL ?>">
    <meta charset="utf-8">

    <title>MVC-TEST</title>


    <style>
 	
	/* your header styles here */

    </style>

</head>

<body>


	<header>

	</header>

	
	
