<?php

class model_index extends Model
{
    function __construct()
    {
        parent::__construct();
    }

    function getSectionVideo()
    {


        $sql = "SELECT * from tbl_section_look WHERE page=1";
        $result = $this->doSelect($sql);
        return $result;
    }

    function  getSectionLook()
    {
        $sql = "SELECT * from tbl_section_look WHERE page=2 ORDER BY id DESC";
        $result = $this->doSelect($sql);
        return $result;
    }


    function getTshirt(){
        $sql = "SELECT * FROM tbl_section_look WHERE page=3 ORDER BY id DESC";
        $result = $this->doSelect($sql);
        return $result;
    }

		
	function newsLetter($form){
        $emails = $form['newsletter'];
        $mailid=$emails;
        $sql = "INSERT INTO tbl_news (email) values (?)";
        $this->doQuery($sql,[$emails]);
		
		require_once('phpmailer/class.phpmailer.php');
		$mail = new PHPMailer(true);
		
		$subject = "خبرنامه هامرز";
		$text_message = "از اینکه به خانواده بزرگ هامرز پیوستین بسیار خرسندیم.";
		$message = "ممنون از ارتباط با ما";
		print_r($mailid);
		try{
			$mail->IsSMTP();
			$mail->isHTML(true);
			$mail->SMTPDebug = 0;
			$mail->SMTPAuth = true;
			$mail->SMTPSecure = "ssl";
			$mail->Host = "hamerztechwear.com";
			$mail->Port =465;
			$mail->AddAddress($mailid);
			$mail->Username = "info@hamerztechwear.com";
			$mail->Password = "dG=&1A@zt1F&";
			$mail->From='info@hamerztechwear.com';
			$mail->FromName='خبرنامه هامرز';
			$mail->ContentType='text/html;charset=utf-8';
			$mail->CharSet='utf-8';
			$mail->Subject = $subject;
			$mail->Body = $message;
			$mail->AltBody = $message;
			if($mail->Send()){
				echo 'ممنون از عضویت شما در خبرنامه هامرز';
			}}
			catch(phpmailerException $ex){
				$msg = " 
				".$ex->errorMessage()." 
				";
			}
		
		require_once('phpmailer/class.phpmailer.php');
		
		$mail = new PHPMailer(true);
		$mailid="aekm.ehsan@gmail.com";
		$subject = "خبر نامه هامرز";
		$text_message = "از اینکه به خانواده بزرگ هامرز پیوستین بسیار خرسندیم.";
		$message = "کاربری جدید با ایمیل:".$emails."در خبرنامه هامرز عضو شد. ";
		
		
		try{
			$mail->IsSMTP();
			$mail->isHTML(true);
			$mail->SMTPDebug = 0;
			$mail->SMTPAuth = true;
			$mail->SMTPSecure = 'ssl';
			$mail->Host = "hamerztechwear.com";
			$mail->Port =465;
			$mail->AddAddress($mailid);
			$mail->Username="info@hamerztechwear.com";
			$mail->Password="dG=&1A@zt1F&";
			$mail->CharSet='utf-8';
			$mail->From='info@hamerztechwear.com';
			$mail->FromName='خبرنامه هامرز';
			$mail->ContentType='text/html;charset=utf-8';
			$mail->Body = $message;
			$mail->AltBody = $message;
			if($mail->Send())
			{
			echo "You have a new user";
			}
			}
			catch(phpmailerException $ex)
			{
			$msg = "
			".$ex->errorMessage()."
			";
			}
		}

}