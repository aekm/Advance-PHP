<?php


class Index  extends Controller
{
    function __construct()
    {
        parent::__construct();
    }

    function index(){

        $sectionVideo = $this->model->getSectionVideo();

        $lookSection  = $this->model->getSectionLook();

        $tshirtSection = $this->model->getTshirt();

        $data = ['video'=>$sectionVideo,'look'=>$lookSection,'tshirt'=>$tshirtSection];

        $this->view('index/index',$data,'',1);

    }
    
    function newsletter(){
		$form = $_POST;
		$this->model->newsLetter($form);
		header('location:'.URL);
	}



}




